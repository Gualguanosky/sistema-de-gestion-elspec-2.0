-- Schema de base de datos para Elspec (Migración desde Firestore)
-- Base de datos: elspec_db

CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100),
    name VARCHAR(255),
    email VARCHAR(255),
    password VARCHAR(255),
    role VARCHAR(50),
    canManageAssets BOOLEAN DEFAULT FALSE,
    uid VARCHAR(128),
    createdAt DATETIME,
    migratedAt DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS products (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255),
    price DECIMAL(15,2),
    discount DECIMAL(5,2),
    category VARCHAR(100),
    extraInfo TEXT,
    createdAt DATETIME,
    updatedAt DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tickets (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(255),
    description TEXT,
    priority VARCHAR(50),
    type VARCHAR(50),
    author VARCHAR(100),
    status VARCHAR(50),
    assignedTo JSON,
    assignedToName VARCHAR(255),
    assetId VARCHAR(100),
    imageUrl TEXT,
    solution TEXT,
    resolutionAttachments JSON,
    closedBy VARCHAR(255),
    closedAt DATETIME,
    reopenedBy VARCHAR(255),
    reopenedAt DATETIME,
    deleted BOOLEAN DEFAULT FALSE,
    deletedAt DATETIME,
    createdAt DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ventas (
    id VARCHAR(50) PRIMARY KEY,
    estado VARCHAR(50),
    createdBy VARCHAR(100),
    createdByName VARCHAR(255),
    lineas JSON,
    cliente JSON,
    configuracion JSON,
    totales JSON,
    createdAt DATETIME,
    updatedAt DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS projects (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255),
    customer VARCHAR(255),
    status VARCHAR(50),
    description TEXT,
    linkedSaleId VARCHAR(50),
    targetDate DATE,
    createdBy VARCHAR(100),
    createdByName VARCHAR(255),
    createdAt DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS quotations (
    id VARCHAR(50) PRIMARY KEY,
    number VARCHAR(50),
    client JSON,
    items JSON,
    notes TEXT,
    total DECIMAL(15,2),
    createdBy VARCHAR(100),
    createdByName VARCHAR(255),
    deleted BOOLEAN DEFAULT FALSE,
    createdAt DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS computers (
    id VARCHAR(50) PRIMARY KEY,
    owner VARCHAR(255),
    brand VARCHAR(100),
    model VARCHAR(100),
    serialNumber VARCHAR(100),
    type VARCHAR(50),
    processor VARCHAR(100),
    ram VARCHAR(50),
    storage VARCHAR(50),
    os VARCHAR(100),
    status VARCHAR(50),
    lastMaintenance DATE,
    notes TEXT,
    createdAt DATETIME,
    updatedAt DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
